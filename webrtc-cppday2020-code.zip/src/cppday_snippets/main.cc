#include "examples/cppday_snippets/sample_snippets.h"

int main() {
  //SampleThread();
  //SampleSocket();
  //SampleIntrusivePtr();
  SampleObserver();
  return 0;
}
