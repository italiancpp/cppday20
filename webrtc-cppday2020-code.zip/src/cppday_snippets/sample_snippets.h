#ifndef EXAMPLES_CPPDAY_SNIPPETS_SAMPLE_SNIPPETS_H_
#define EXAMPLES_CPPDAY_SNIPPETS_SAMPLE_SNIPPETS_H_

void SampleThread();
void SampleSocket();
void SampleIntrusivePtr();
void SampleObserver();

#endif  // EXAMPLES_CPPDAY_SNIPPETS_SAMPLE_SNIPPETS_H_